console.log("Email Assisstant Extension - Script Loaded");

function createAIButton(){
    const button = document.createElement('div');
    button.className = 'T-I J-J5-Ji aoO v7 T-I-atl L3';
    button.style.marginRight = '8px';
    button.innerHTML = 'AI Reply';
    button.setAttribute('role', 'button');
    button.setAttribute('data-tooltip', 'Generate AI Reply');
    return button;
}

function findComposedToolBar() {
    const selectors = [
        ".btC",
        ".aDh",
        '[role="toolbar"]',
        ".gU.Up"
    ];

    for (const selector of selectors) {
        const toolbar = document.querySelector(selector);
        if (toolbar) {
            return toolbar;
        }
    }

    return null;
}

function getEmailContent() {
    const selectors = [
        ".h7",
        ".a3s.aiL",
        ".gmail_quote",
        '[role="presentation"]'
    ];

    for (const selector of selectors) {
        const content = document.querySelector(selector);

        if (content) {
            return content.innerText.trim();
        }
    }

    return "";
}

function injectButton() {
    const existingButton = document.querySelector('.ai-reply-button');
        if(existingButton) existingButton.remove();

        const toolbar = findComposedToolBar();
        if(!toolbar){
            console.log("ToolBar not found");
            return;
        }

        console.log("ToolBar Found, Creating AI Button");
        const button = createAIButton();
        button.classList.add('ai-reply-button');

        button.addEventListener('click', async() => {
            try {
                button.innerHTML = 'Generating...';
                button.disabled = true;

                const emailContent = getEmailContent();
                const response = await fetch('https://smart-email-assistant-fqgy.onrender.com/api/email/generate', {
                    method : 'POST',
                    headers : {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        emailContent: emailContent,
                        tone: "Professional"
                    })
                });

                if(!response.ok){
                    throw new Error('API Request Failed');
                }

                   const generatedReply = await response.text();
                   const composeBox = document.querySelector('[role="textbox"][g_editable="true"]');

                   if (composeBox){
                        composeBox.focus();
                        document.execCommand('insertText', false, generatedReply);
                   }
                   else{
                    console.error('Compose box was not found');
                    
                   }
            } catch (error) {
                console.error(error);
                alert('Failed to generate reply');
            }finally{
                button.innerHTML = 'AI Reply';
                button.disabled = false;
            }
        });

        toolbar.insertBefore(button, toolbar.firstChild);

}

const observer = new MutationObserver(() => {

    const composeDialog = document.querySelector('[role="dialog"]');
    const replyEditor = document.querySelector('[aria-label="Message Body"]');

  if ((composeDialog || replyEditor) &&
    !document.querySelector(".ai-reply-button")) {

    console.log("Compose Window Detected");
    injectButton();
}

});

observer.observe(document.body, {
    childList: true,
    subtree: true
});